 
"""
Shared Data Model analyzer.
 
Sends the cross-workbook mapping metrics and table inventory to OpenAI
to identify reuse opportunities and recommend how Tableau datasources
should consolidate into Power BI semantic models.
"""
 
from __future__ import annotations
 
import json
from typing import Any
 
from app.services.ai.openai_client import OpenAIAnalysisClient
from app.services.ai.prompts import SHARED_DATA_MODEL_SYSTEM_PROMPT
from app.utils.naming import build_datasource_name_lookup
 
 
async def analyze_shared_data_model(
    client: OpenAIAnalysisClient, workbook_bundles: list[dict[str, Any]]
) -> dict[str, Any]:
    datasource_to_reports: dict[str, list[str]] = {}
    table_to_datasources: dict[str, set[str]] = {}
 
    for bundle in workbook_bundles:
        # mappings.datasource_to_reports is already keyed by datasource
        # caption (see app.services.discovery.mapping_service) -- nothing
        # to translate there. table_to_datasources below is built
        # independently straight from data_model.tables, though, which
        # only carries the internal datasource name -- resolve that here
        # so it doesn't leak an opaque id into the LLM payload/output.
        ds_name_lookup = build_datasource_name_lookup(bundle)
 
        mappings = bundle.get("mappings", {})
        for ds_name, reports in mappings.get("datasource_to_reports", {}).items():
            existing = set(datasource_to_reports.get(ds_name, []))
            existing.update(reports)
            datasource_to_reports[ds_name] = sorted(existing)
 
        for table in bundle.get("data_model", {}).get("tables", []):
            table_name = table.get("table") or table.get("name", "")
            key = table_name
            owning_datasource = ds_name_lookup.get(table.get("datasource", ""), table.get("datasource", ""))
            table_to_datasources.setdefault(key, set()).add(owning_datasource)
 
    payload = {
        "datasource_to_reports": datasource_to_reports,
        "table_to_datasources": {k: sorted(v) for k, v in table_to_datasources.items()},
    }
 
    if not datasource_to_reports and not table_to_datasources:
        return {"shared_datasources": [], "shared_tables": [], "recommended_semantic_models": []}
 
    response = await client.complete_json(
        system_prompt=SHARED_DATA_MODEL_SYSTEM_PROMPT,
        user_prompt=json.dumps(payload, default=str),
    )
 
    return {
        "shared_datasources": response.get("shared_datasources", []),
        "shared_tables": response.get("shared_tables", []),
        "recommended_semantic_models": response.get("recommended_semantic_models", []),
    }